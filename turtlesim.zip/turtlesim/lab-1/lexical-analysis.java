import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class Lexical {
    static ArrayList<String> parseIdentifier(String line, ArrayList<String> list, ArrayList<String> keywords){
        if(line.contains("="))
        {
            String[] arr = line.split("=");
            ArrayList<String> cleaned = new ArrayList<String>();
            for (String i: arr){
                String clean = i.trim();
                String[] sub_clean = clean.split(" ");
                for (String j: sub_clean){
                    if (!keywords.contains(j)){
                        cleaned.add(j);
                    }
                }
            }
            return cleaned;
        }
        else {
            return new ArrayList<String>();
        }
        
    }

    static ArrayList<String> parseKeyWords(String line, ArrayList<String> list){
        ArrayList<String> keywords = new ArrayList<String>();
            keywords.add("public");
            keywords.add("private");
            keywords.add("int");
            keywords.add("float");
            keywords.add("String");
            keywords.add("ArrayList");
            keywords.add("ArrayList<String>");
            keywords.add("import");
        
        String[] arr = line.split(" ");
        for (String i: arr){
            if (keywords.contains(i)){
                list.add(i);
            }
        }

        return list;
    }

    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        String s;
        ArrayList<String> arr = new ArrayList<String>();
       do {
        s = sc.nextLine();
        String newStr = s.trim();
        arr.add(newStr);
       }
        while (!s.isEmpty());

    System.out.println("----------------------------------------------------------");    
    HashMap<String, ArrayList<String>> lexical_collection = new HashMap<String, ArrayList<String>>();
    ArrayList<String> dummy = new ArrayList<String>();
    
    lexical_collection.put("keywords", new ArrayList<String>());
    lexical_collection.put("constants", new ArrayList<String>());
    lexical_collection.put("identifiers", new ArrayList<String>());
    lexical_collection.put("udf", new ArrayList<String>());

    for (String i: arr){
        parseKeyWords(i, lexical_collection.get("keywords"));
        parseIdentifier(i, lexical_collection.get("identifiers"));
    }
    
        System.out.println("Printing the keywords");
        System.out.println("----------------------------------------------------------");
        System.out.println(lexical_collection.get("keywords").toString());
        System.out.println("----------------------------------------------------------");
        System.out.println("Printing the Identfiers");
        System.out.println("----------------------------------------------------------");
        System.out.println(lexical_collection.get("identifiers").toString());
        System.out.println("----------------------------------------------------------");
    }
}
