import java.util.*;

class LeftFactoring {
    public static void main(String[] argx){
        Scanner sc = new Scanner(System.in);
        String inp = sc.nextLine();
        
    }
}