#include <iostream>
#include <stack>
#include <string>
#include <map>

using namespace std;

// Function to check if a character is an operator
bool isOperator(char c)
{
    return c == '+' || c == '-' || c == '*' || c == '/';
}

// Function to check if a character is an operand
bool isOperand(char c)
{
    return isalpha(c);
}

// Function to determine precedence of an operator
int precedence(char op)
{
    if (op == '+' || op == '-')
        return 1;
    if (op == '*' || op == '/')
        return 2;
    return 0;
}

// Function to convert infix expression to Three Address Code
string toThreeAddressCode(const string &expression)
{
    stack<char> operators;
    stack<string> operands;
    map<string, string> threeAddressCode;
    int tempVarCounter = 1;

    // Iterating through the expression
    for (char c : expression)
    {
        if (c == ' ')
            continue; // Skipping spaces

        else if (isOperand(c))
        {
            string operand(1, c);
            operands.push(operand);
        }
        else if (isOperator(c))
        {
            while (!operators.empty() && precedence(operators.top()) >= precedence(c))
            {
                string op2 = operands.top();
                operands.pop();
                string op1 = operands.top();
                operands.pop();
                string tempVar = "t" + to_string(tempVarCounter++);
                operands.push(tempVar);
                // Generating Three Address Code
                threeAddressCode[tempVar] = op1 + " " + operators.top() + " " + op2;
                operators.pop();
            }
            operators.push(c);
        }
    }

    // Processing remaining operators
    while (!operators.empty())
    {
        string op2 = operands.top();
        operands.pop();
        string op1 = operands.top();
        operands.pop();
        string tempVar = "t" + to_string(tempVarCounter++);
        operands.push(tempVar);
        // Generating Three Address Code
        threeAddressCode[tempVar] = op1 + " " + operators.top() + " " + op2;
        operators.pop();
    }

    // Constructing the result string
    string result;
    for (const auto &entry : threeAddressCode)
    {
        result += entry.first + " = " + entry.second + "\n";
    }

    return result;
}

int main()
{
    string input;
    cout << "Enter the arithmetic expression: ";
    getline(cin, input);

    string threeAddress = toThreeAddressCode(input);

    cout << "Three Address Code:" << endl;
    cout << threeAddress << endl;

    return 0;
}
