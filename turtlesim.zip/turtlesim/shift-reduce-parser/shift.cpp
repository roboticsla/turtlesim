#include <iostream>
#include <string>

struct ProductionRule
{
    std::string left;
    std::string right;
};

int main()
{
    std::string input, stack, temp, ch, token1, token2, substring;
    int i, j, stack_length, substring_length, stack_top, rule_count = 0;
    ProductionRule rules[10];

    stack = "";

    std::cout << "\nEnter the number of production rules: ";
    std::cin >> rule_count;

    std::cout << "\nEnter the production rules (in the form 'left->right'): \n";
    for (i = 0; i < rule_count; i++)
    {
        std::cin >> temp;
        size_t pos = temp.find("->");
        token1 = temp.substr(0, pos);
        token2 = temp.substr(pos + 2);
        rules[i].left = token1;
        rules[i].right = token2;
    }

    std::cout << "\nEnter the input string: ";
    std::cin >> input;

    i = 0;
    while (true)
    {
        // If there are more characters in the input string, add the next character to the stack
        if (i < input.length())
        {
            ch = input[i];
            i++;
            stack += ch;
            std::cout << stack << "\t";
            for (int k = i; k < input.length(); k++)
            {
                std::cout << input[k];
            }
            std::cout << "\tShift " << ch << std::endl;
        }
        
        // Iterate through the production rules
        for (j = 0; j < rule_count; j++)
        {
            // Check if the right-hand side of the production rule matches a substring in the stack
            size_t found = stack.find(rules[j].right);
            if (found != std::string::npos)
            {
                // Replace the matched substring with the left-hand side of the production rule
                stack_length = stack.length();
                substring_length = rules[j].right.length();
                stack_top = stack_length - substring_length;
                stack.erase(stack_top);
                stack += rules[j].left;
                std::cout << stack << "\t";
                for (int k = i; k < input.length(); k++)
                {
                    std::cout << input[k];
                }
                std::cout << "\tReduce " << rules[j].left << "->" << rules[j].right << std::endl;
                j = -1; // Restart the loop to ensure immediate reduction of the newly derived production rule
            }
        }

        // Check if the stack contains only the start symbol and if the entire input string has been processed
        if (stack == rules[0].left && i == input.length())
        {
            std::cout << "\nAccepted";
            break;
        }

        // Check if the entire input string has been processed but the stack doesn't match the start symbol
        if (i == input.length())
        {
            std::cout << "\nNot Accepted";
            break;
        }
    }

    return 0;
}