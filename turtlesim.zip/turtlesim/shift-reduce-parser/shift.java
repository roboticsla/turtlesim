import java.util.Scanner;

interface ProductionRule {
    String left;
    String right;
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input, stack = "", temp, ch, token1, token2;
        int i, j, stack_length, substring_length, stack_top, rule_count = 0;
        ProductionRule[] rules = new ProductionRule[10];

        System.out.print("Enter the number of production rules: ");
        rule_count = scanner.nextInt();

        System.out.println("Enter the production rules (in the form 'left->right'): ");
        for (i = 0; i < rule_count; i++) {
            temp = scanner.next();
            int pos = temp.indexOf("->");
            token1 = temp.substring(0, pos);
            token2 = temp.substring(pos + 2);
            rules[i] = new ProductionRule();
            rules[i].left = token1;
            rules[i].right = token2;
        }

        System.out.print("Enter the input string: ");
        input = scanner.next();

        i = 0;
        while (true) {
            if (i < input.length()) {
                ch = String.valueOf(input.charAt(i));
                i++;
                stack += ch;
                System.out.print(stack + "\t");
                for (int k = i; k < input.length(); k++) {
                    System.out.print(input.charAt(k));
                }
                System.out.println("\tShift " + ch);
            }

            for (j = 0; j < rule_count; j++) {
                int found = stack.indexOf(rules[j].right);
                if (found != -1) {
                    stack_length = stack.length();
                    substring_length = rules[j].right.length();
                    stack_top = stack_length - substring_length;
                    stack = stack.substring(0, stack_top) + rules[j].left;
                    System.out.print(stack + "\t");
                    for (int k = i; k < input.length(); k++) {
                        System.out.print(input.charAt(k));
                    }
                    System.out.println("\tReduce " + rules[j].left + "->" + rules[j].right);
                    j = -1;
                }
            }

            if (stack.equals(rules[0].left) && i == input.length()) {
                System.out.println("\nAccepted");
                break;
            }

            if (i == input.length()) {
                System.out.println("\nNot Accepted");
                break;
            }
        }
    }
}