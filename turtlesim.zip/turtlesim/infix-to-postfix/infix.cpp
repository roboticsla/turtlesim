    #include <iostream>
    #include <stack>
    #include <algorithm>
    #include <string>

    using namespace std;

    bool isOperator(char c) {
        return (c == '+' || c == '-' || c == '*' || c == '/');
    }

    int precedence(char c) {
        if (c == '+' || c == '-') return 1;
        if (c == '*' || c == '/') return 2;
        return 0;
    }

    string infixToPostfix(const string& expression) {
        string postfix;
        stack<char> s;

        for (char c : expression) {
            if (isalnum(c)) {
                postfix += c;
            }
            else if (c == '(') {
                s.push(c);
            }
            else if (c == ')') {
                while (!s.empty() && s.top() != '(') {
                    postfix += s.top();
                    s.pop();
                }
                s.pop();
            }
            else if (isOperator(c)) {
                while (!s.empty() && precedence(c) <= precedence(s.top())) {
                    postfix += s.top();
                    s.pop();
                }
                s.push(c);
            }
        }

        while (!s.empty()) {
            postfix += s.top();
            s.pop();
         }

        return postfix;
    }

    string reverseString(const string& str) {
        string reversed = str;
        reverse(reversed.begin(), reversed.end());
        return reversed;
    }

    int main() {
        string infix_expression;
        cout << "Enter an infix expression: ";
        getline(cin, infix_expression);

        string postfix_expression = infixToPostfix(infix_expression);
        cout << "Postfix expression: " << postfix_expression << endl;

        string prefix_expression = reverseString(postfix_expression);
        cout << "Prefix expression: " << prefix_expression << endl;

        return 0;
    }
