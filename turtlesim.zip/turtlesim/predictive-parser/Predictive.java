import java.util.*;

// S -> aBDh
//  B -> cC

class Predictive {

    static Map<String, List<String>> firstMap = new HashMap<>();
    static Map<String, List<String>> followMap = new HashMap<>();

    static void printFirst(){
        for (Map.Entry<String, List<String>> entry : firstMap.entrySet()) {
            System.out.println("First(" + entry.getKey() + ") = " + entry.getValue());
        }
    }

    static void printFollow(){
        for (Map.Entry<String, List<String>> entry : followMap.entrySet()) {
            System.out.println("Follow(" + entry.getKey() + ") = " + entry.getValue());
        }
    }

    static class Production {
        String startState;
        String endState;
        List<String> nonTerminals;
    
        public Production(String startState, String endState, List<String> nonTerminals) {
            this.startState = startState;
            this.endState = endState;
            this.nonTerminals = nonTerminals;
        }

        public List<String> getItems(){
            List<String> items = new ArrayList<>();
            String[] nonTerminalsArray = this.endState.split("");
            for (String nonTerminal : nonTerminalsArray) {
                if (this.nonTerminals.contains(nonTerminal)) {
                    items.add(nonTerminal);
                }
            }
            return items;
        }

        public List<String> getNonTerminals() {
            return this.nonTerminals;
        }

        public void findFirst() {
            String firstNonTerminal = this.endState.substring(0, 1);

            if (this.nonTerminals.contains(firstNonTerminal) == false) {
                if (firstMap.get(this.startState) == null) {
                    firstMap.put(this.startState, new ArrayList<>());
                }
                List<String> firstList = firstMap.get(this.startState);
                firstList.add(firstNonTerminal);
                firstMap.put(this.startState, firstList);
            }
        }

        public void findFollow(){
            
        }
      
    }


    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of productions: ");
        int n = sc.nextInt();
        Production prod[] = new Production[n];

        for(int i=0; i<n; i++){
            System.out.println("Enter the start state: ");
            String startState = sc.next();
            System.out.println("Enter the end state: ");
            String endState = sc.next();
            System.out.println("Enter the non-terminals: ");
            String nonTerminalsInput = sc.next();
            String[] nonTerminalsArray = nonTerminalsInput.split("");
            List<String> nonTerminalsList = new ArrayList<>();
            for (String nonTerminal : nonTerminalsArray) {
                nonTerminalsList.add(nonTerminal);
            }
            prod[i] = new Production(startState, endState, nonTerminalsList);
        }
        sc.close();
        System.out.println("The productions are: ");


        for(int i=0; i<n; i++){
            prod[i].findFollow(prod);
            // System.out.print(prod[i].startState + " -> " + prod[i].endState);
            // System.out.println(" with non-terminals: " + String.join(", ", prod[i].nonTerminals));
        }
        printFirst();
    }
}
