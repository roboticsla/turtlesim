import java.util.*;

class Solve {

  public static int findCommonLength(String str1, String str2) {
    int minLength = Math.min(str1.length(), str2.length());
    int i = 0;
    while (i < minLength && str1.charAt(i) == str2.charAt(i)) {
      i++;
    }
    return i;
  }

  static ArrayList<Productions> solve_left_recursion(Productions production) {
    ArrayList<Productions> result = new ArrayList<>();
    result.add(production);
    String nonTerminal = production.nonTerminal;
    ArrayList<String> productions = new ArrayList<>(production.productions);

    for (String prod : productions) {
      if (prod.charAt(0) == nonTerminal.charAt(0)) {
        String newNonTerminal = nonTerminal + "'";
        String newProd = prod.substring(1) + newNonTerminal;
        production.removeProduction(prod);
        production.addProduction(newProd);
        result.add(
          new Productions(
            newNonTerminal,
            new ArrayList<>(
              Arrays.asList(
                prod.substring(1, prod.length() - 1) + newNonTerminal,
                "ε"
              )
            )
          )
        );
      }
    }

    return result;
  }

  static void solve_left_factoring(Productions production) {
    String nonTerminal = production.nonTerminal;
    ArrayList<String> productions = new ArrayList<>();
    productions.addAll(production.productions);
    ArrayList<Productions> result = new ArrayList<>();

    int max_len = 0;

    for (int i = 1; i < productions.size(); i++) {
      max_len =
        Math.max(
          max_len,
          findCommonLength(productions.get(i - 1), productions.get(i))
        );
    }

    if (max_len <= 0) {
      return;
    }

    ArrayList<String> augmented = new ArrayList<>();

    for (int i = 0; i < productions.size(); i++) {
      if (productions.get(i).length() > max_len) {
        augmented.add(productions.get(i).substring(max_len));
      } else {
        augmented.add(productions.get(i));
      }
    }

    ArrayList<String> resprod = new ArrayList<>();
    resprod.add(productions.get(0).substring(0, max_len) + "β");

    result.add(new Productions(nonTerminal, resprod));

    result.add(new Productions("β", augmented));

    for (Productions prod : result) {
      System.out.println(prod.toString());
    }
  }

  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);

    System.out.println("Enter the number of productions: ");
    int n = sc.nextInt();

    ArrayList<Productions> grammar = new ArrayList<>();

    for (int i = 0; i < n; i++) {
      System.out.println("Enter the non-terminal: ");
      String nonTerminal = sc.next();
      System.out.println(
        "Enter the number of productions for " + nonTerminal + ": "
      );
      int m = sc.nextInt();
      ArrayList<String> productions = new ArrayList<>();
      for (int j = 0; j < m; j++) {
        System.out.println("Enter the production: ");
        productions.add(sc.next());
      }

      grammar.add(new Productions(nonTerminal, productions));
    }
    sc.close();

    ArrayList<Productions> copy_recursion_grammar = new ArrayList<>();

    System.out.println("\n====================================\n");

    System.out.println("Left Recursion: ");
    for (Productions production : grammar) {
      copy_recursion_grammar.addAll(solve_left_recursion(production));
    }

    for (Productions prod : copy_recursion_grammar) {
      System.out.println(prod.toString());
    }

    ArrayList<Productions> copy_factoring_grammar = new ArrayList<>();

    System.out.println("\n====================================\n");

    System.out.println("Left factoring: ");
    for (Productions production : grammar) {
      solve_left_factoring(production);
    }
  }
}

class Productions {

  String nonTerminal;
  ArrayList<String> productions;

  Productions(String nonTerminal, ArrayList<String> productions) {
    this.nonTerminal = nonTerminal;
    this.productions = productions;
  }

  public String toString() {
    return this.nonTerminal + " -> " + this.productions.toString();
  }

  void addProduction(String production) {
    this.productions.add(production);
  }

  void removeProduction(String production) {
    this.productions.remove(production);
  }
}
