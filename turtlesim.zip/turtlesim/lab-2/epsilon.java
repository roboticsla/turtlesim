import java.util.*;

class Epsilon {

  public static void main(String args[]) {
    ArrayList<String> s_transition = new ArrayList<String>();
    Scanner sc = new Scanner(System.in);
    System.out.println("---------------------------");
    System.out.println("Demoing for single input value");
    System.out.println("You can have either a or epsilon but not both");
    // int input_symbols = 2;
    // String[] symbols = {"epsilon", "a"};
    System.out.println("---------------------------");
    System.out.println("Enter the number of transitions");
    int transitions = sc.nextInt();
    sc.nextLine();
    System.out.println("---------------------------");
    System.out.println(transitions + " is the number of transitions");
    System.out.println(
      "Type state-transition-state for inputs ! It is case sensitive"
    );

    for (int i = 0; i < transitions; i++) {
      System.out.println("Input transition " + (i + 1));
      String inp = sc.nextLine();
      s_transition.add(inp);
      System.out.println(inp + " was the transition");
    }
    sc.close();
    // ArrayList<ArrayList<ArrayList<Integer>>> txn = new ArrayList<ArrayList<ArrayList<Integer>>>();
    // Outer array list represents input symbols
    Set<String> states = new LinkedHashSet<String>();
    for (String i : s_transition) {
      String[] command = i.split("-");
      if (!states.contains(command[0])) {
        states.add(command[0]);
      } else if (!states.contains(command[2])) {
        states.add(command[2]);
      }
    }

    int matrix_size = states.size() + 1;

    int[][] epsilon_matrix = new int[matrix_size][matrix_size];
    int[][] a_matrix = new int[matrix_size][matrix_size];

    for (String i : s_transition) {
      String[] command = i.split("-");
      if (command[1].equals("e")) {
        epsilon_matrix[Integer.parseInt(command[0])][Integer.parseInt(command[2])] = 1;
      } else if (command[1].equals("a")) {
        a_matrix[Integer.parseInt(command[0])][Integer.parseInt(command[2])] =
          1;
      }
    }

    System.out.println("Epsilon Closure matrix");
    for (int i = 0; i < matrix_size; i++) {
      for (int j = 0; j < matrix_size; j++) {
        System.out.print(epsilon_matrix[i][j] + " ");
      }
      System.out.println();
    }
    // Ford Fulkerson algorithm
    for (int i = 0; i < matrix_size; i++) {
      for (int j = 0; j < matrix_size; j++) {
        for (int k = 0; k < matrix_size; k++) {
          if (epsilon_matrix[i][k] * epsilon_matrix[k][j] == 1) {
            epsilon_matrix[i][k] = 1;
          }
        }
      }
    }

    for (int i = 0; i < matrix_size; i++) {
      for (int j = 0; j < matrix_size; j++) {
        if (epsilon_matrix[i][j] == 1) {
          System.out.println(
            "There is an epsilon connection from: " + i + " to " + j
          );
        }
      }
    }
  }
}
